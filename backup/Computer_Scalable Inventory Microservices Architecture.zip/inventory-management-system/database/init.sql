-- Initialize Database
CREATE DATABASE IF NOT EXISTS inventory_db;
USE inventory_db;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin', 'user') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Inventory Table
CREATE TABLE IF NOT EXISTS inventory (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    quantity INT NOT NULL DEFAULT 0,
    min_threshold INT NOT NULL DEFAULT 10,
    unit VARCHAR(20) NOT NULL,
    category VARCHAR(50),
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

-- Vendors Table
CREATE TABLE IF NOT EXISTS vendors (
    id INT PRIMARY KEY AUTO_INCREMENT,
    company_name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    specialty VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Vendor_Inventory Table (Many-to-Many)
CREATE TABLE IF NOT EXISTS vendor_inventory (
    id INT PRIMARY KEY AUTO_INCREMENT,
    vendor_id INT NOT NULL,
    inventory_id INT NOT NULL,
    is_primary BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (vendor_id) REFERENCES vendors(id) ON DELETE CASCADE,
    FOREIGN KEY (inventory_id) REFERENCES inventory(id) ON DELETE CASCADE,
    UNIQUE KEY unique_vendor_item (vendor_id, inventory_id)
);

-- Notifications Table
CREATE TABLE IF NOT EXISTS notifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    type ENUM('low_stock', 'vendor_contact', 'system') NOT NULL,
    message TEXT NOT NULL,
    user_id INT,
    vendor_id INT,
    inventory_id INT,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (vendor_id) REFERENCES vendors(id) ON DELETE SET NULL,
    FOREIGN KEY (inventory_id) REFERENCES inventory(id) ON DELETE SET NULL
);

-- Contact_History Table
CREATE TABLE IF NOT EXISTS contact_history (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    vendor_id INT NOT NULL,
    inventory_id INT NOT NULL,
    message TEXT NOT NULL,
    contact_type ENUM('email', 'phone', 'in_person') DEFAULT 'email',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (vendor_id) REFERENCES vendors(id) ON DELETE CASCADE,
    FOREIGN KEY (inventory_id) REFERENCES inventory(id) ON DELETE CASCADE
);

-- Create indexes for better performance
CREATE INDEX idx_inventory_quantity ON inventory(quantity);
CREATE INDEX idx_inventory_category ON inventory(category);
CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_is_read ON notifications(is_read);
CREATE INDEX idx_contact_history_user_id ON contact_history(user_id);
CREATE INDEX idx_contact_history_vendor_id ON contact_history(vendor_id);

-- Insert sample data
INSERT INTO users (username, email, password_hash, role) VALUES 
('admin', 'admin@inventory.com', '$2b$10$Kj3Gjp7gT7Xo5y9xR8ZpOe3bVvZj9xR8ZpOe3bVvZj9xR8ZpOe3b', 'admin'),
('john_doe', 'john@example.com', '$2b$10$Kj3Gjp7gT7Xo5y9xR8ZpOe3bVvZj9xR8ZpOe3bVvZj9xR8ZpOe3b', 'user'),
('jane_smith', 'jane@example.com', '$2b$10$Kj3Gjp7gT7Xo5y9xR8ZpOe3bVvZj9xR8ZpOe3bVvZj9xR8ZpOe3b', 'user');

INSERT INTO inventory (name, description, quantity, min_threshold, unit, category, created_by) VALUES 
('Laptop Dell XPS 13', 'High-performance laptop for development', 15, 5, 'units', 'Electronics', 1),
('Wireless Mouse', 'Ergonomic wireless mouse', 45, 10, 'units', 'Accessories', 1),
('USB-C Cable', 'USB-C charging cable 1m', 120, 20, 'units', 'Accessories', 1),
('Monitor 27" 4K', '4K monitor for development', 8, 3, 'units', 'Electronics', 1),
('Keyboard Mechanical', 'Mechanical keyboard RGB', 25, 8, 'units', 'Accessories', 1),
('Webcam HD', '1080p HD webcam', 12, 5, 'units', 'Electronics', 1),
('Office Chair', 'Ergonomic office chair', 6, 2, 'units', 'Furniture', 1),
('Desk Lamp', 'LED desk lamp', 18, 5, 'units', 'Accessories', 1);

INSERT INTO vendors (company_name, contact_person, email, phone, address, specialty) VALUES 
('TechSupply Co', 'Michael Johnson', 'contact@techsupply.com', '+1-555-0101', '123 Tech Street, San Francisco, CA', 'Electronics'),
('OfficePro Inc', 'Sarah Williams', 'sales@officepro.com', '+1-555-0102', '456 Office Ave, New York, NY', 'Office Supplies'),
('DevEquip Ltd', 'David Brown', 'info@devequip.com', '+1-555-0103', '789 Dev Road, Austin, TX', 'Development Equipment'),
('GlobalTech', 'Lisa Chen', 'orders@globaltech.com', '+1-555-0104', '321 Global Blvd, Seattle, WA', 'Technology'),
('WorkSpace Solutions', 'Robert Davis', 'support@workspacesol.com', '+1-555-0105', '654 Work Lane, Denver, CO', 'Furniture');

INSERT INTO vendor_inventory (vendor_id, inventory_id, is_primary) VALUES 
(1, 1, TRUE),   -- TechSupply Co supplies Laptops
(1, 4, FALSE),  -- TechSupply Co also supplies Monitors
(2, 2, TRUE),   -- OfficePro supplies Wireless Mice
(2, 3, TRUE),   -- OfficePro supplies USB-C Cables
(2, 8, TRUE),   -- OfficePro supplies Desk Lamps
(3, 5, TRUE),   -- DevEquip supplies Keyboards
(3, 6, TRUE),   -- DevEquip supplies Webcams
(5, 7, TRUE);   -- WorkSpace Solutions supplies Office Chairs

INSERT INTO notifications (type, message, user_id, inventory_id) VALUES 
('low_stock', 'Laptop Dell XPS 13 is running low (15 units remaining)', 1, 1),
('system', 'Welcome to Inventory Management System!', 2, NULL),
('system', 'Weekly inventory report generated', 1, NULL);

INSERT INTO contact_history (user_id, vendor_id, inventory_id, message, contact_type) VALUES 
(1, 1, 1, 'Need to order 10 more laptops by next week', 'email', 'email'),
(2, 2, 2, 'Inquiring about bulk pricing for wireless mice', 'email', 'email'),
(1, 3, 5, 'Keyboard quality is excellent, need 15 more units', 'phone', 'phone');

-- Create a simple view for dashboard
CREATE VIEW dashboard_summary AS
SELECT 
    (SELECT COUNT(*) FROM inventory) as total_items,
    (SELECT COUNT(*) FROM inventory WHERE quantity <= min_threshold) as low_stock_items,
    (SELECT COUNT(*) FROM vendors) as total_vendors,
    (SELECT COUNT(*) FROM notifications WHERE is_read = FALSE) as unread_notifications;